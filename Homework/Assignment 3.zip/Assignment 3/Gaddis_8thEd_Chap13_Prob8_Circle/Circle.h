/* 
 * File:   Circle.h
 * Author: Ivan Burgos
 * Created on August 29, 2018, 2:35 PM
 * Purpose:  Specification for the circle class
 */

#ifndef CIRCLE_H
#define CIRCLE_H

class Circle{
    private:
        float radius;
        float pi;
    public:
        Circle(){setRadius(0);pi=3.14159;}
        Circle(float r){setRadius(r);pi=3.14159;}
        void setRadius(float r){radius=r;}
        float getRadius()const{return radius;}
        float getArea()const{return radius*radius*pi;}
        float getDiameter()const{return radius*2;}
        float getCrcmfe()const{return 2*radius*pi;}
};

#endif /* CIRCLE_H */

