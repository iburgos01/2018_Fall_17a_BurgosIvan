/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on August 29, 2018, 2:35 PM
 * Purpose:  Create a CSC/CIS 5 Template
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries
#include "Circle.h"
//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float radius;
    //Initialize Variables
    cout<<"Enter the radius of the circle"<<endl;
    cin>>radius;
    Circle info(radius);
    //Process/Map inputs to outputs
    
    //Output data
    cout<<"Area:          "<<info.getArea()<<endl;
    cout<<"Diameter:      "<<info.getDiameter()<<endl;
    cout<<"Circumference: "<<info.getCrcmfe()<<endl;
    //Exit stage right!
    return 0;
}