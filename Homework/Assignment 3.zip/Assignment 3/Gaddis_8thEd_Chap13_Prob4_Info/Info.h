/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Info.h
 * Author: koola
 *
 * Created on October 31, 2018, 1:47 PM
 */

#ifndef INFO_H
#define INFO_H

#include <string>
using namespace std;

class Info{
    private:
        string name;
        string address;
        int age;
        string phNum;
    public:
        void setName(string n){name=n;}    //Sets the name of the person
        void setAdrs(string a){address=a;} //Sets the address
        void setAge(int a){age=a;}         //Sets the age
        void setPhNum(string p){phNum=p;}     //Sets the phone number
        string getName()const{return name;}
        string getAdrs()const{return address;}
        int getAge()const{return age;}
        string getPhNum()const{return phNum;}
};

#endif /* INFO_H */

