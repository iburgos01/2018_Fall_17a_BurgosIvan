/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on August 29, 2018, 2:35 PM
 * Purpose:  Create a CSC/CIS 5 Template
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries
#include "Info.h"
//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int size=3;
    string name,address,phNum; //Use to hold the name and the address
    int age;       //Use to hold the age and phone number
    Info person[size];
    
    //Initialize Variables
    for(int i=0;i<size;i++){
    cout<<"Enter a name"<<endl;
    getline(cin,name);
    cout<<"Enter the address"<<endl;
    getline(cin,address);
    cout<<"Enter age"<<endl;
    cin>>age;
    cin.ignore();
    cout<<"Enter phone number"<<endl;
    getline(cin,phNum);
    person[i].setName(name);
    person[i].setAdrs(address);
    person[i].setAge(age);
    person[i].setPhNum(phNum);
    }
    //Process/Map inputs to outputs
    
    //Output data
    for(int i=0;i<size;i++){
        cout<<"Name:         "<<person[i].getName()<<endl;
        cout<<"Address:      "<<person[i].getAdrs()<<endl;
        cout<<"Age:          "<<person[i].getAge()<<endl;
        cout<<"Phone number: "<<person[i].getPhNum()<<endl;
    }
    //Exit stage right!
    return 0;
}