/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on August 29, 2018, 2:35 PM
 * Purpose:  Use to store the item information
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries
#include "Inventory.h"
//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int item,num,cost;
    //Initialize Variables
    cout<<"Enter the item's number"<<endl;
    cin>>item;
    cout<<"Enter the number on hand"<<endl;
    cin>>num;
    cout<<"Enter the cost of the item"<<endl;
    cin>>cost;
    Item info(item,num,cost);
    //Process/Map inputs to outputs
    
    //Output data
    cout<<"Item Number:    "<<info.gtItmNm()<<endl;
    cout<<"Number on hand: "<<info.getQtity()<<endl;
    cout<<"Cost:           "<<info.getCost()<<endl;
    cout<<"Total Cost:     "<<info.gtTtlCt()<<endl;
    
    //Exit stage right!
    return 0;
}