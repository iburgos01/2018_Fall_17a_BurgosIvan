/* 
 * File:   Inventory.h
 * Author: Ivan Burgos
 * Created on November 5th, 2018, 12:48 PM
 * Purpose:  Specification of the Inventory class
 */

#ifndef INVENTORY_H
#define INVENTORY_H

class Item{
    private:
        int itmNum;    //Used to hold the item's number
        int qtity;     //Used to hold the number of the item on hand
        float cost;    //The cost of the item
        float ttlCost; //The cost of the item on hand
    public: 
        Item();
        Item(int,int,float);
        void stItmNum(int a){itmNum=a;}
        void setQtity(int b){qtity=b;}
        void setCost(float c){cost=c;}
        void stTtlCt(float d){ttlCost=d;}
        int gtItmNm() const{return itmNum;}
        int getQtity() const{return qtity;}
        float getCost() const{return cost;}
        float gtTtlCt() const{return ttlCost;}
};

#endif /* INVENTORY_H */

