/* 
 * File:   Inventory.cpp
 * Author: Ivan Burgos
 * Created on November 5th, 2018, 1:02 PM
 * Purpose:  Process the item information 
 */

//System Libraries
#include <iostream>  //Output/Input Library
using namespace std;
//User Libraries
#include "Inventory.h"

Item::Item(){
    itmNum=0;
    qtity=0;
    cost=0;
    ttlCost=0;
}

Item::Item(int itm, int num, float cst){
    float tlCst;
    stItmNum(itm);
    setQtity(num);
    setCost(cst);
    tlCst=cost*qtity;
    stTtlCt(tlCst);
}

