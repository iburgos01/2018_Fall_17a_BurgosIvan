/* 
 * File:   TestScores.cpp
 * Author: Ivan Burgos
 * Created on November 5th, 2018, 4:13 PM
 * Purpose:  Set and get average of student scores
 */

//System Libraries
using namespace std;

//User Libraries
#include "TestScores.h"

Scores::Scores(int n){
    size=n<0?3:n;
    scores=new int(size);
}

void Scores::setScores(int *ts, int index){
    if(index>=0&&index<size)scores[index]=ts[index];
    else scores[index]=0;
}
float Scores::getAvrge(){
    float average;
    for(int i=0;i<size;i++){
        average+=scores[i];
    }
    return average/size;
}