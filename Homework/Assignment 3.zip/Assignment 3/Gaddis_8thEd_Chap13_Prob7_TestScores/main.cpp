/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on November 5th, 2018, 4:17 PM
 * Purpose:  Get test Scores for the class
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries
#include "TestScores.h"
//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int size=3;
    Scores grade(size);
    int *info;
    
    //Initialize Variables
    info=new int[size];
    cout<<"Enter the test scores"<<endl;
    for(int i=0;i<size;i++){
        cin>>info[i];
        grade.setScores(info,i);
    }
    //Process/Map inputs to outputs
    delete []info;
    cout<<"Average grade: "<<grade.getAvrge()<<endl;
    //Output data
    
    //Exit stage right!
    return 0;
}