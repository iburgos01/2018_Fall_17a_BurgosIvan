/* 
 * File:   TestScores.h
 * Author: Ivan Burgos
 * Created on November 5th, 2018, 4:09 PM
 * Purpose:  Specification for the Scores class
 */

#ifndef TESTSCORES_H
#define TESTSCORES_H

class Scores{
    private:
        int size;
        int *scores;
    public:
        Scores(int);
        ~Scores(){delete []scores;}
        void setScores(int *,int);
        int getScores(int index){return scores[index];}
        float getAvrge();
};

#endif /* TESTSCORES_H */

