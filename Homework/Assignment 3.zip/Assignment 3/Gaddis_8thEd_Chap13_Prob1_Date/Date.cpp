/* 
 * File:   Date.cpp
 * Author: Ivan Burgos
 * Created on October 31, 2018, 12:14 PM
 * Purpose:  Print out the date
 */

//System Libraries
#include <iostream>
using namespace std;

//User Library
#include "Date.h"

void Date::print(){
    string nameMon=getMonth();
    cout<<month<<"/"<<day<<"/"<<year<<endl;
    cout<<nameMon<<" "<<day<<","<<year<<endl;
    cout<<day<<" "<<nameMon<<","<<year<<endl;    
}

string Date::getMonth(){
    string nameMon;
    switch(month){
        case 1:nameMon="January";break;
        case 2:nameMon="February";break;
        case 3:nameMon="March";break;
        case 4:nameMon="April";break;
        case 5:nameMon="May";break;
        case 6:nameMon="June";break;
        case 7:nameMon="July";break;
        case 8:nameMon="August";break;
        case 9:nameMon="September";break;
        case 10:nameMon="October";break;
        case 11:nameMon="November";break;
        case 12:nameMon="December";break;
    }
    
    return nameMon;
}