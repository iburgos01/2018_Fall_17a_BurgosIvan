/* 
 * File:   Date.cpp
 * Author: Ivan Burgos
 * Created on October 31, 2018, 12:20 PM
 * Purpose:  Specification for the Date Class
 */

#ifndef DATE_H
#define DATE_H
class Date{
    private:
        int month;
        int day;
        int year;
    public:
        void setMon(int m){month=m;}
        void setDay(int d){day=d;}
        void setYear(int y){year=y;}    
        void print();
        string getMonth();
};

#endif /* DATE_H */

