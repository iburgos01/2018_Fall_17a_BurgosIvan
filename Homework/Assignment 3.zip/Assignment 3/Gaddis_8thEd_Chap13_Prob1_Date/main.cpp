/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on October 31st, 2018, 2:35 PM
 * Purpose:  Display the date input
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries
#include "Date.h"

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int month,day,year;
    Date date;
    //Initialize Variables
    do{
    cout<<"Enter the month: ";
    cin>>month;
    cout<<"Enter the day: ";
    cin>>day;
    cout<<"Enter the year: ";
    cin>>year;
    }while((day<1||day>31)||(month<1||month>12));
    //Process/Map inputs to outputs
    date.setMon(month);
    date.setDay(day);
    date.setYear(year);
    //Output data
    date.print();
    //Exit stage right!
    return 0;
}