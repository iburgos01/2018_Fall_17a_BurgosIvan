/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 5, 2018, 10:28 AM
 * Purpose:  Converting Celsius to Fahrenheit
 */

//System Libraries
#include <iostream>  //Output/Input Library
#include <iomanip>   //Formatting Library
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float Cel,Fahr;  //Variables used to hold degrees in 
                     //Celsius and Fahrenheit
    float Convert=1.8; //The Fraction used in conversion
    //Initialize Variables
    cout<<"Enter the degrees in Celsius"<<endl; //Used to get the temp in Celsius 
    cin>>Cel;                                   //to convert to Fahrenheit
    //Process/Map inputs to outputs
    Fahr=Convert*Cel+32;  //Formula used to Convert Celsius to Fahrenheit
    //Output data
    cout<<fixed<<showpoint<<setprecision(2)<<endl; //Used to show two spaces passed
                                                   //the decimal point 
    cout<<"Temperature Degrees"<<endl;  //Output the Temperature Degrees
    cout<<"Celsius: "<<Cel<<endl;
    cout<<"Fahrenheit: "<<Fahr<<endl;
    //Exit stage right!
    return 0;
}