/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 5, 2018, 10:47 AM
 * Purpose:  Converting Dollar to Yen and Euros
 */

//System Libraries
#include <iostream>  //Output/Input Library
#include <iomanip>   //Formatting Library
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float Dollar;  //The dollar amount to be converted
    float DlrToYen,DlrToEuro; //Amounts used to convert dollar to Yen and Euro
    float Yen, Euro; //Dollar amount in Yen and Euro
    //Initialize Variables
    cout<<"Enter the Dollar amount to be converted"<<endl; //Gets Dollar amount to 
    cin>>Dollar;                                     //be converted to Yen and Euro
    //Process/Map inputs to outputs
    
    //Output data
    cout<<fixed<<showpoint<<setprecision(2)<<endl; //Used to show two spaces passed
                                                   //the decimal point 
    cout<<"Temperature Degrees"<<endl;  //Output the Temperature Degrees
    cout<<"Celsius: "<<Cel<<endl;
    cout<<"Fahrenheit: "<<Fahr<<endl;
    //Exit stage right!
    return 0;
}